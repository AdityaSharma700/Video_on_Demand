
public class testing {
   
    public static void main(String[] args) {
        
      String ans=  myClient.fetchIndex();
        System.out.println("--->"+ans);
    }
    
}
